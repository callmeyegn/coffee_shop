menu = {
    "coffee": 80000,
    "tea": 50000,
    "cake": 120000
}


def show_menu():
    print("---------- Menu ----------")
    for name in menu:
        print(name, ":", menu[name], "Toman")
