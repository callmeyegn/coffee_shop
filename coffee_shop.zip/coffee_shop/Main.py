from Menu import show_menu
from Order import add_order, show_orders
from Billing import calculate_total, print_invoice

while True:
    print()
    print("========== Coffee Shop ==========")
    print("1. نمایش منوی کافه")
    print("2. ثبت سفارش")
    print("3. نمایش سفارش ها")
    print("4. محاسبه مبلغ کل")
    print("5. چاپ فاکتور")
    print("6. خروج")

    choice = input("انتخاب شما: ")

    if choice == "1":
        show_menu()
    elif choice == "2":
        add_order()
    elif choice == "3":
        show_orders()
    elif choice == "4":
        print("مبلغ کل:", calculate_total())
    elif choice == "5":
        print_invoice()
    elif choice == "6":
        print("خداحافظ!")
        break
    else:
        print("گزینه نامعتبر است!")
