from Menu import menu

# لیست سفارش ها (هر سفارش یک دیکشنری است)
orders = []


def add_order():
    name = input("اسم محصول: ").strip().lower()

    if name not in menu:
        print("این محصول توی منو نیست!")
        return

    count_text = input("تعداد: ")
    if not count_text.isdigit() or int(count_text) <= 0:
        print("تعداد نامعتبر است!")
        return

    count = int(count_text)
    order = {"name": name, "price": menu[name], "count": count}
    orders.append(order)
    print("سفارش ثبت شد.")


def show_orders():
    if len(orders) == 0:
        print("هنوز سفارشی ثبت نشده.")
        return

    print("---------- Orders ----------")
    for order in orders:
        print(order["name"], "| قیمت:", order["price"], "| تعداد:", order["count"])
