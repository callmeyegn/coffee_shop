from Order import orders


def calculate_total():
    total = 0
    for order in orders:
        total = total + order["price"] * order["count"]
    return total


def calculate_discount(total):
    if total > 1000000:
        discount = total * 10 / 100
    else:
        discount = 0
    return discount


def print_invoice():
    if len(orders) == 0:
        print("سفارشی برای صدور فاکتور وجود ندارد.")
        return

    total = calculate_total()
    discount = calculate_discount(total)
    final = total - discount

    print("---------- Invoice ----------")
    for order in orders:
        print(order["name"], "x", order["count"])
    print("مبلغ کل:", total)
    print("تخفیف:", discount)
    print("مبلغ نهایی:", final)
